import { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  StatusBar,
  Animated,
} from 'react-native';

const classificarIMC = (imc) => {
  if (imc < 18.5) return { label: 'Abaixo do Peso', cor: '#F59E0B', corFundo: '#FEF3C7', emoji: '⚠️' };
  if (imc < 25.0) return { label: 'Peso Normal', cor: '#10B981', corFundo: '#D1FAE5', emoji: '✅' };
  if (imc < 30.0) return { label: 'Sobrepeso', cor: '#D97706', corFundo: '#FDE68A', emoji: '⚠️' };
  if (imc < 35.0) return { label: 'Obesidade Grau I', cor: '#F97316', corFundo: '#FFEDD5', emoji: '🔴' };
  if (imc < 40.0) return { label: 'Obesidade Grau II (Severa)', cor: '#EF4444', corFundo: '#FEE2E2', emoji: '🔴' };
  return { label: 'Obesidade Grau III (Mórbida)', cor: '#991B1B', corFundo: '#FEE2E2', emoji: '🚨' };
};

export default function App() {
  const [peso, setPeso] = useState('');
  const [altura, setAltura] = useState('');
  const [resultado, setResultado] = useState(null);
  const [erro, setErro] = useState('');

  const calcularIMC = () => {
    setErro('');
    setResultado(null);

    const pesoNum = parseFloat(peso.replace(',', '.'));
    const alturaNum = parseFloat(altura.replace(',', '.'));

    if (!peso || !altura) {
      setErro('Por favor, preencha todos os campos.');
      return;
    }
    if (isNaN(pesoNum) || isNaN(alturaNum)) {
      setErro('Insira valores numéricos válidos.');
      return;
    }
    if (pesoNum <= 0 || alturaNum <= 0) {
      setErro('Os valores devem ser maiores que zero.');
      return;
    }
    if (alturaNum > 3) {
      setErro('Altura deve ser em metros (ex: 1.75).');
      return;
    }

    const imc = pesoNum / (alturaNum * alturaNum);
    const classificacao = classificarIMC(imc);
    setResultado({ imc: imc.toFixed(2), ...classificacao });
  };

  const limpar = () => {
    setPeso('');
    setAltura('');
    setResultado(null);
    setErro('');
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <StatusBar barStyle="light-content" backgroundColor="#1E3A5F" />

      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerEmoji}>⚖️</Text>
        <Text style={styles.headerTitulo}>Calculadora IMC</Text>
        <Text style={styles.headerSubtitulo}>Índice de Massa Corporal</Text>
      </View>

      {/* Card de Entrada */}
      <View style={styles.card}>
        <Text style={styles.cardTitulo}>Seus Dados</Text>

        <Text style={styles.label}>Peso (kg)</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: 70.5"
          placeholderTextColor="#9CA3AF"
          keyboardType="numeric"
          value={peso}
          onChangeText={setPeso}
        />

        <Text style={styles.label}>Altura (m)</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex: 1.75"
          placeholderTextColor="#9CA3AF"
          keyboardType="numeric"
          value={altura}
          onChangeText={setAltura}
        />

        {erro ? (
          <View style={styles.erroContainer}>
            <Text style={styles.erroTexto}>❌ {erro}</Text>
          </View>
        ) : null}

        <TouchableOpacity style={styles.botaoCalcular} onPress={calcularIMC} activeOpacity={0.85}>
          <Text style={styles.botaoTexto}>Calcular IMC</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.botaoLimpar} onPress={limpar} activeOpacity={0.85}>
          <Text style={styles.botaoLimparTexto}>Limpar</Text>
        </TouchableOpacity>
      </View>

      {/* Resultado */}
      {resultado && (
        <View style={[styles.resultadoCard, { backgroundColor: resultado.corFundo, borderColor: resultado.cor }]}>
          <Text style={styles.resultadoEmoji}>{resultado.emoji}</Text>
          <Text style={styles.resultadoLabel}>Seu IMC</Text>
          <Text style={[styles.resultadoIMC, { color: resultado.cor }]}>{resultado.imc}</Text>
          <Text style={[styles.resultadoClassificacao, { color: resultado.cor }]}>{resultado.label}</Text>
        </View>
      )}

      {/* Tabela de Referência */}
      <View style={styles.card}>
        <Text style={styles.cardTitulo}>Tabela de Referência (OMS)</Text>
        {[
          { label: 'Abaixo do Peso', faixa: '< 18.5', cor: '#F59E0B' },
          { label: 'Peso Normal', faixa: '18.5 – 24.9', cor: '#10B981' },
          { label: 'Sobrepeso', faixa: '25.0 – 29.9', cor: '#D97706' },
          { label: 'Obesidade Grau I', faixa: '30.0 – 34.9', cor: '#F97316' },
          { label: 'Obesidade Grau II', faixa: '35.0 – 39.9', cor: '#EF4444' },
          { label: 'Obesidade Grau III', faixa: '≥ 40.0', cor: '#991B1B' },
        ].map((item, index) => (
          <View key={index} style={styles.tabelaLinha}>
            <View style={[styles.tabelaCor, { backgroundColor: item.cor }]} />
            <Text style={styles.tabelaLabel}>{item.label}</Text>
            <Text style={[styles.tabelaFaixa, { color: item.cor }]}>{item.faixa}</Text>
          </View>
        ))}
      </View>

      <Text style={styles.rodape}>Fatec • Lab. Desenvolvimento Web • Prof. Neymar</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F4F8',
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    backgroundColor: '#1E3A5F',
    borderRadius: 20,
    padding: 28,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#1E3A5F',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
  headerEmoji: {
    fontSize: 44,
    marginBottom: 8,
  },
  headerTitulo: {
    fontSize: 26,
    fontWeight: '800',
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },
  headerSubtitulo: {
    fontSize: 14,
    color: '#93C5FD',
    marginTop: 4,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  cardTitulo: {
    fontSize: 17,
    fontWeight: '700',
    color: '#1E3A5F',
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 6,
  },
  input: {
    borderWidth: 1.5,
    borderColor: '#D1D5DB',
    borderRadius: 10,
    padding: 14,
    fontSize: 16,
    color: '#111827',
    backgroundColor: '#F9FAFB',
    marginBottom: 16,
  },
  erroContainer: {
    backgroundColor: '#FEE2E2',
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
  },
  erroTexto: {
    color: '#991B1B',
    fontSize: 14,
    fontWeight: '500',
  },
  botaoCalcular: {
    backgroundColor: '#1E3A5F',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 10,
    shadowColor: '#1E3A5F',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  botaoTexto: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  botaoLimpar: {
    borderWidth: 1.5,
    borderColor: '#D1D5DB',
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
  },
  botaoLimparTexto: {
    color: '#6B7280',
    fontSize: 15,
    fontWeight: '600',
  },
  resultadoCard: {
    borderWidth: 2,
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
  },
  resultadoEmoji: {
    fontSize: 40,
    marginBottom: 8,
  },
  resultadoLabel: {
    fontSize: 13,
    color: '#6B7280',
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 4,
  },
  resultadoIMC: {
    fontSize: 52,
    fontWeight: '800',
    lineHeight: 60,
  },
  resultadoClassificacao: {
    fontSize: 18,
    fontWeight: '700',
    marginTop: 6,
  },
  tabelaLinha: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  tabelaCor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 10,
  },
  tabelaLabel: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
    fontWeight: '500',
  },
  tabelaFaixa: {
    fontSize: 13,
    fontWeight: '700',
  },
  rodape: {
    textAlign: 'center',
    color: '#9CA3AF',
    fontSize: 12,
    marginTop: 4,
  },
});