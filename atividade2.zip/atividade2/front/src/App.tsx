import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch, RootState } from "../src/assets/redux/store";
import { addUser, incrementAge, removeUser } from "../src/assets/redux/slices/userSlice";
import type { User } from "../src/assets/redux/slices/userSlice";
import { useState } from "react";
import "./App.css";

export default function App() {
  const users = useSelector((state: RootState) => state.userObject.users);
  const [id, setId] = useState(1);
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [error, setError] = useState("");

  const dispatch: AppDispatch = useDispatch();

  const handleSave = () => {
    if (!name.trim() || !age) {
      setError("Preencha nome e idade.");
      return;
    }
    if (isNaN(Number(age)) || Number(age) <= 0) {
      setError("Idade inválida.");
      return;
    }
    setError("");
    const user: User = { id, name: name.trim(), age: parseInt(age) };
    dispatch(addUser(user));
    setId((prev: number) => prev + 1);
    setName("");
    setAge("");
  };

  const handleAge = (id: number) => {
    dispatch(incrementAge(id));
  };

  const handleRemove = (e: React.MouseEvent<HTMLButtonElement>, id: number) => {
    e.preventDefault();
    dispatch(removeUser(id));
  };

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-inner">
          <div className="logo">
            <span className="logo-icon">⬡</span>
            <span className="logo-text">UserBase</span>
          </div>
          <div className="header-badge">
            <span className="badge-dot" />
            Redux · Aula 03
          </div>
        </div>
      </header>

      <main className="main">
        {/* Left: Form */}
        <section className="panel form-panel">
          <div className="panel-label">NOVO USUÁRIO</div>
          <h2 className="panel-title">Cadastrar</h2>

          <div className="field">
            <label className="field-label" htmlFor="name">Nome completo</label>
            <input
              id="name"
              className="field-input"
              placeholder="Ex: Maria Silva"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSave()}
            />
          </div>

          <div className="field">
            <label className="field-label" htmlFor="age">Idade</label>
            <input
              id="age"
              className="field-input"
              placeholder="Ex: 28"
              type="number"
              min="1"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSave()}
            />
          </div>

          {error && <div className="error-msg">⚠ {error}</div>}

          <button className="btn-primary" onClick={handleSave}>
            <span>+</span> Adicionar Usuário
          </button>

          <div className="stats-row">
            <div className="stat-card">
              <span className="stat-value">{users.length}</span>
              <span className="stat-label">Usuários</span>
            </div>
            <div className="stat-card">
              <span className="stat-value">
                {users.length > 0
                  ? Math.round(users.reduce((a, u) => a + u.age, 0) / users.length)
                  : "—"}
              </span>
              <span className="stat-label">Média de idade</span>
            </div>
          </div>
        </section>

        {/* Right: User list */}
        <section className="panel list-panel">
          <div className="panel-label">REGISTROS</div>
          <h2 className="panel-title">Usuários</h2>

          {users.length === 0 ? (
            <div className="empty-state">
              <span className="empty-icon">👤</span>
              <p>Nenhum usuário cadastrado ainda.</p>
              <p className="empty-sub">Adicione um usuário ao lado para começar.</p>
            </div>
          ) : (
            <ul className="user-list">
              {users.map((user, index) => (
                <li
                  key={user.id}
                  className="user-card"
                  style={{ animationDelay: `${index * 0.04}s` }}
                >
                  <div className="user-avatar">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="user-info">
                    <span className="user-name">{user.name}</span>
                    <span className="user-meta">ID #{user.id}</span>
                  </div>
                  <div className="user-age-block">
                    <span className="user-age">{user.age}</span>
                    <span className="user-age-label">anos</span>
                  </div>
                  <div className="user-actions">
                    <button
                      className="btn-icon btn-inc"
                      title="Incrementar idade"
                      onClick={() => handleAge(user.id)}
                    >
                      +1
                    </button>
                    <button
                      className="btn-icon btn-del"
                      title="Remover usuário"
                      onClick={(e) => handleRemove(e, user.id)}
                    >
                      ✕
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>

      <footer className="footer">
        Fatec · Lab. Desenvolvimento Web · Prof. Neymar
      </footer>
    </div>
  );
}